//
//  LoginViewController.swift
//  C0720752_Midterm_MADT2018
//
//  Created by Ferdin Norbert on 2018-02-28.
//  Copyright © 2018 Ferdin Norbert. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var studentId: UITextField!
    @IBOutlet weak var passwordLogin: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var n = Student(studentId: "C0720752", studentName: "Ferdin", studentPassword : "admin" ,gender: "Male", courseName: "MADT", studentEmail: "ferd@gmail.com", birthDate: "12/03/995", percentage: 90, totalMarks: 100, marks: [10.00,20.00])
    
    
    @IBAction func loginPressed(_ sender: Any) {
        
        if(studentId.text == n.idStrn() && passwordLogin.text == "admin") // Read from private effective user settings warning
        {
            return
        }
        else
        {
            let alertController = UIAlertController(title: "Invalid studentID or login password", message: "Please enter new one", preferredStyle: .alert)
            
           
            let defaultAction = UIAlertAction(title: "Close", style: .default, handler: nil)
            
            
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
            
        }
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

