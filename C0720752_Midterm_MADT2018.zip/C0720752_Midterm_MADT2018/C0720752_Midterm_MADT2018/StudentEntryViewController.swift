//
//  StudentEntryViewController.swift
//  C0720752_Midterm_MADT2018
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 Ferdin Norbert. All rights reserved.
//

import UIKit

class StudentEntryViewController: UIViewController
,UIPickerViewDelegate , UIPickerViewDataSource{
  
    

    //var obj = Student()
    
    @IBOutlet weak var pickerVw: UIPickerView!
    
    @IBOutlet weak var stdName: UITextField!
    @IBOutlet weak var stdEmail: UITextField!
    @IBOutlet weak var genderSelect: UISegmentedControl!
    @IBOutlet weak var dateSeletion: UITextField!
    
    
    @IBOutlet weak var markOne: UITextField!
    @IBOutlet weak var markTwo: UITextField!
    @IBOutlet weak var markThree: UITextField!
    @IBOutlet weak var markFour: UITextField!
    @IBOutlet weak var markFive: UITextField!
    
   
    var pickerData: [String] = [String]()
    
    var selection:String!
    override func viewDidLoad() {
        super.viewDidLoad()

        pickerVw.delegate = self
        pickerVw.dataSource = self
        
        // Do any additional setup after loading the view.
        pickerData = ["MADT" , "MFDT" , "PM"]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //selection = pickerData[row]
        return pickerData[row]
    }
    

    /*
    @IBAction func checkResult(_ sender: Any) {
       
        if(stdName.text == "" && stdEmail.text == "" && dateSeletion.text == "")
        {
            let alertController = UIAlertController(title: "Invalid studentID or login password", message: "Please enter new one", preferredStyle: .alert)
            
            
            let defaultAction = UIAlertAction(title: "Close", style: .default, handler: nil)
            
            
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
        }
        else
        {
            obj.stdNameReturn(studentName: stdName.text!)
            obj.stdEmail(studentEmail: stdEmail.text!)
            
            if(genderSelect.selectedSegmentIndex == 0)
            {
                obj.stdGender(gender: "Male")
            }
            else if(genderSelect.selectedSegmentIndex == 1)
            {
                obj.stdGender(gender: "Female")
            }
            
            obj.stdCourse(courseName: selection)
            
            obj.marksList(marks: [NumberFormatter().number(from: markOne.text!)!.floatValue,NumberFormatter().number(from: markTwo.text!)!.floatValue,NumberFormatter().number(from: markThree.text!)!.floatValue,NumberFormatter().number(from: markFour.text!)!.floatValue,NumberFormatter().number(from: markFive.text!)!.floatValue]
            )
            
            
            
              }
        }
        */
  
    
   /* @IBAction func datePickerChanged(sender: UIDatePicker) {
        
        print("print \(sender.date)")
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MMM dd, YYYY"
        let somedateString = dateFormatter.stringFromDate(sender.date)
        
        print(somedateString)  // "somedateString" is your string date
    }
 */
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
