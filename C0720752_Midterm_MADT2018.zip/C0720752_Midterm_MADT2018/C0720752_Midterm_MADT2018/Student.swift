//
//  Student.swift
//  C0720752_Midterm_MADT2018
//
//  Created by MacStudent on 2018-02-28.
//  Copyright © 2018 Ferdin Norbert. All rights reserved.
//

import Foundation


class Student

{
    
    var studentId:String!
    var studentName:String!
    var studentPassword:String!
    var gender:String!
    var courseName:String!
    var studentEmail:String!
    var birthDate:String!
    var percentage:Float!
    var totalMarks:Float!
    var marks:[Float]!
    
    init()
    {
        
    }
    
    init(studentId :String , studentName :String , studentPassword : String ,gender : String , courseName : String, studentEmail : String , birthDate : String , percentage : Float , totalMarks : Float , marks :[Float]) {
        
        self.studentId = studentId
        self.studentName = studentName
        self.gender = gender
        self.courseName = courseName
        self.studentEmail = studentEmail
        self.birthDate = birthDate
        self.percentage = percentage
        self.totalMarks = totalMarks
        self.marks = marks
        
    }
    
    func idStrn() -> String
    {
        
        return studentId
    }
    func nmeStrn() -> String
    {
        return studentName
    }
    
    func pwdStrn() -> String
    {
        return studentPassword
    }
    
    
    
    func stdNameReturn(studentName: String)
    {
        self.studentName = studentName
    }
    
    func stdEmail(studentEmail: String)
    {
       self.studentEmail = studentEmail
    }
    
    func stdGender(gender : String)
    {
       self.gender = gender
    }
    func stdCourse(courseName : String)
    {
        self.courseName = courseName
    }
    
    func marksList(marks:[Float])
    {
        self.marks = marks
    }
    
    func stdBirth(birthDate : String)
    {
        self.birthDate = birthDate
    }
    
    
}
