//
//  SignUp.swift
//  day3
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Register  {
    
    var uId:String!
    var uName:String!
    var uEmail:String!
    var uPassword:String!
    
 static var userList = [String:Register]()
   
    init()
    {
    }
    
    init(uname:String,uemail:String,upass:String) {
        self.uName = uname
        self.uEmail = uemail
        self.uPassword = upass
        
}
    
   /*func getName() -> String
    {
        return uName
    }
    
    func getEmail() -> String
    {
        return uEmail
    }
    
    func getPassword() -> String
    {
        return uPassword
    }*/
    
   static func addUsers(user:Register)->Bool
    {
        if self.userList[user.uEmail] == nil{
           self.userList[user.uEmail] = user
            return true
        }
        
      
        
        return false
        
    }
    static func  getAllusers()->[String:Register]
    {
        return userList
    }
    
    
    
    
}
