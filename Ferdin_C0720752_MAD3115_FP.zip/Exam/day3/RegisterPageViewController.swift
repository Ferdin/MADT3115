//
//  RegisterPageViewController.swift
//  day3
//
//  Created by MacStudent on 2018-02-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegisterPageViewController: UIViewController {

  
    
    @IBOutlet weak var userIdTextField: UITextField!
    
    
    @IBOutlet weak var userNameTextField: UITextField?
   
    @IBOutlet weak var userEmailTextField: UITextField?
    
    
    @IBOutlet weak var userPasswordTextField: UITextField?
    
    @IBOutlet weak var repeatPasswordTextField: UITextField?
    
  //  static var addUsers = [Register(uname:"kiran",uemail: "k@k.com",upass:"k1234")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userIdTextField.text=String(randomInt(min: 1, max: 100))

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var loginVC:LoginViewController?
    
    
    @IBAction func registerButtonTapped(_ sender: Any) {
        
      let userId=userIdTextField.text
     let userName = userNameTextField?.text
      let userEmail = userEmailTextField?.text
       let userPassword = userPasswordTextField?.text
     let userRepeatPassword = repeatPasswordTextField?.text
        let r1 = Register()
        r1.uId = userId!
        r1.uName = userName
        r1.uEmail = userEmail
        r1.uPassword = userPassword
  
        
        
        
        
       // RegisterPageViewController.addUsers.append(Register(uname: userName!, uemail: userEmail!, upass: userPassword!))
        
        // check for empty fields
        if ((userName?.isEmpty)! || (userEmail!.isEmpty) || (userPassword!.isEmpty) || (userRepeatPassword!.isEmpty))
        {
            // Display alert message
            displayMyAlertMessage(userMessage: "All Fields are Required");
           //return;
        }
    else   if (userRepeatPassword != userPassword)
        {
            displayMyAlertMessage(userMessage: "Passwords do not match");
            //return;
        }
        
        // store data
    //  UserDefaults.standard.set(userName, forKey: "userName")
      //  UserDefaults.standard.set(userEmail,forKey: "userEmail")
      //  UserDefaults.standard.set(userPassword,forKey: "userPassword")
       // UserDefaults.standard.synchronize()
        
        // Display alert message with confirmation
       else
        {
            let flag =  Register.addUsers(user: r1)
            if flag == true
            {
                print("data saved")
                
            }
            else{
                print("no data")
            }
        let myAlert = UIAlertController(title: "Alert", message: "Regitration is successful.Thank you", preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {_ in
            self.segue()}
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
            
            
        }}

    
    func displayMyAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }

func segue()
{
    let storyBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    let NextVC = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginViewController
    self.present(NextVC,animated: true,completion: nil)
    
    
}
    func randomInt(min: Int, max:Int) -> Int {
        return min + Int(arc4random_uniform(UInt32(max - min + 1)))
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
