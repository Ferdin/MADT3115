//
//  AddTicketViewController.swift
//  day3
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit


class AddTicketViewController: UIViewController , UIPickerViewDataSource ,UIPickerViewDelegate,UITextFieldDelegate{

    
    
    
    @IBOutlet weak var logoImg: UIImageView!
    
    
    @IBOutlet weak var dateLbl: UILabel!
    
    
    @IBOutlet weak var rateLbl: UILabel!
    @IBOutlet weak var carNumber: UITextField!
    @IBOutlet weak var carBrand: UITextField!
    @IBOutlet weak var carColor: UITextField!

    let carBrandNames = ["BMW","Ferrari","Jaguar","Mercedes","Hyundai"]
    let carColorNames = ["Red" , "Green" , "Blue" , "White" , "Black" , "Yellow"]
    let spotNames = ["East Toronto" , "1221 Brampton" , "54 Etobicoke" , "Scarborough Town Center"]
    let laneNames = ["A1","A2","A3","B1","B2","B3"]
    let paymentMethods = ["Debit" , "Credit" , "Cash" , "Interac" , "Paypal" , "Bitcoin"]
        
    var pickerView1 : UIPickerView!
    var activeTextField = 0
    var activeTF : UITextField!
    var activeValue = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //  self.pickerView?.delegate=selfr
        //self.pickerView?.dataSource=self
        // Do any additional setup after loading the view.
        self.dateLbl.text=displayDate(date: Date())
        carBrand.delegate = self
        carColor.delegate = self
        parkingLane.delegate = self
        parkingSpot.delegate = self
        paymentMethod.delegate = self
        
        
    }
    
    @IBAction func selectHourSegment(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex==0
        {
            rateLbl.text="$5.00"
            
        }
        else if sender.selectedSegmentIndex==1
        {
            rateLbl.text="$10.00"
        }
        else if sender.selectedSegmentIndex==2
        {
            rateLbl.text="$15.00"
        }
        else if sender.selectedSegmentIndex==3
        {
            rateLbl.text="$20.00"
        }
        else{
            rateLbl.text="$25.00"
        }
    }
    
    
    
    @IBOutlet weak var parkingLane: UITextField!
    
    @IBOutlet weak var parkingSpot: UITextField!
    
    @IBOutlet weak var paymentMethod: UITextField!
    
    @IBAction func saveAddTicket(_ sender: Any) {
        
    }
    

    
    @IBAction func savaDetailButton(_ sender: UIButton) {
        
        let carNum = carNumber.text
        let rateLab = rateLbl.text
        
        let carBrandName = carBrand.text
        let carColorName = carColor.text
        let laneName = parkingLane.text
        let spotName = parkingSpot.text
        let payMethod = paymentMethod.text
        
       
        
        
        let t1 = AddTicket()
        t1.Number = carNum
        t1.Brand = carBrandName
        t1.Color = carColorName
        t1.Lane = laneName
        t1.Spot = spotName
        t1.Payment = payMethod
        t1.Rate = rateLab
        
        
        if ((carNum!.isEmpty) || (carBrandName!.isEmpty) || (carColorName!.isEmpty) || (laneName!.isEmpty)
            || (spotName!.isEmpty) || (payMethod!.isEmpty) || (rateLab!.isEmpty))
        {
            // Display alert message
            displayMyAlertMessage(userMessage: "All Fields are Required");
            //return;
        }
        else
        {
            let flag =  AddTicket.addticket(ticket: t1)
            if flag == true
            {
                print("data saved")
                
            }
            else{
                print("no data")
            }
            displayMyAlertMessage(userMessage: "Succesfully added your ticket")
            return;
        }
        
    }
    
   
    
    
    
    func displayDate(date:Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE dd/MM/yyyy"
        let dateStr = formatter.string(from: date)
        return dateStr
    }
    
    
    
  

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch activeTextField {
        case 1:
            return carBrandNames.count
        case 2:
            return carColorNames.count
        case 3:
            return laneNames.count
        case 4:
            return spotNames.count
        case 5:
            return paymentMethods.count
        default:
            return 0
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch activeTextField {
        case 1:
            return carBrandNames[row]
        case 2:
            return carColorNames[row]
        case 3:
            return laneNames[row]
        case 4:
            return spotNames[row]
        case 5:
            return paymentMethods[row]
        default:
            return""
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch activeTextField {
        case 1:
            activeValue = carBrandNames[row]
            if(activeValue == "BMW")
            {
                logoImg.image = UIImage(named : "BMW.png")
            }
            else if(activeValue == "Ferrari")
            {
                logoImg.image = UIImage(named : "Ferrari.png")
            }
            else if(activeValue == "Jaguar")
            {
                logoImg.image = UIImage(named : "Jaguar.png")
            }
            else if(activeValue == "Mercedes")
            {
                logoImg.image = UIImage(named : "Mercedes.png")
            }
            else if(activeValue == "Hyundai")
            {
                logoImg.image = UIImage(named : "Hyundai.png")
            }
                
            else
            {
                logoImg.image = UIImage(named : "parking.png")
            }
        case 2:
            activeValue = carColorNames[row]
        case 3:
           activeValue = laneNames[row]
        case 4:
            activeValue = spotNames[row]
        case 5:
            activeValue = paymentMethods[row]
        default:
            activeValue = ""
    }
        
        
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch  textField {
        case carBrand:
             activeTextField = 1
        case carColor:
            activeTextField = 2
        case parkingLane:
            activeTextField = 3
        case parkingSpot:
            activeTextField = 4
        case paymentMethod:
            activeTextField = 5
            
        default:
            activeTextField = 0
            
        }
        
        activeTF = textField
        
        self.pickUpValue(textField: textField)
    }
    func pickUpValue(textField:UITextField)
        
    {
        pickerView1 = UIPickerView(frame:CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: self.view.frame.size.width, height: 216)))
        // create frame and size of picker view
       
        
        // deletates
        pickerView1.delegate = self
        pickerView1.dataSource = self
        
        // if there is a value in current text field, try to find it existing list
        if let currentValue = textField.text {
            
            var row : Int?
            
            // look in correct array
            switch activeTextField {
            case 1:
                row = carBrandNames.index(of: currentValue)
            case 2:
                row = carColorNames.index(of: currentValue)
            case 3:
                row = laneNames.index(of: currentValue)
            case 4:
                row = spotNames.index(of: currentValue)
            case 2:
                row = paymentMethods.index(of: currentValue)
                
            default:
                row = nil
            }
            
            // we got it, let's set select it
            if row != nil {
                pickerView1.selectRow(row!, inComponent: 0, animated: true)
            }
        }
        
        pickerView1.backgroundColor = UIColor.white
        textField.inputView = self.pickerView1
        
        // toolBar
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        toolBar.barTintColor = UIColor.darkGray
        toolBar.sizeToFit()
        
        // buttons for toolBar
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelClick))
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        textField.inputAccessoryView = toolBar
    
    }
    
    @objc func doneClick() {
        activeTF.text = activeValue
        activeTF.resignFirstResponder()
        
    }
    
    // cancel
    @objc func cancelClick() {
        activeTF.resignFirstResponder()
    }
    func displayMyAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

    
    


