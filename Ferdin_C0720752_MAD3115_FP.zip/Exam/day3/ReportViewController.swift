//
//  ReportViewController.swift
//  day3
//
//  Created by MacStudent on 2018-03-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ReportViewController: UIViewController {

   
    

    @IBOutlet weak var brandLabel: UILabel!
    @IBOutlet weak var colorLabel: UILabel!
    @IBOutlet weak var laneLabel: UILabel!
    @IBOutlet weak var carNumLbl: UILabel!
    @IBOutlet weak var payLbl: UILabel!
    @IBOutlet weak var rate: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        let ticketList = AddTicket.getAlltickets()
        var s = String()
        var n = String()
        var d = String()
        var o = String()
        var y = String()
        var r = String()
        
        for (key, value) in ticketList{
            s = value.Brand
            n = value.Color
            d = value.Lane
            o = value.Number
            y = value.Payment
            r = value.Rate
           // s +=  "\(key) -- > \(value.Color!)\n"
           // s +=  "\(key) -- > \(value.Lane!)\n"
           // s +=  "\(key) -- > \(value.Number!)\n"
           // s +=  "\(key) -- > \(value.Payment!)\n"
           // s +=  "\(key) -- > \(value.Rate!)\n"
           // s +=  "\(key) -- > \(value.Spot!)\n"
        }
        print(s)
        
        brandLabel.text = s
        colorLabel.text = n
        laneLabel.text = d
        carNumLbl.text = o
        payLbl.text = y
        rate.text = r
        // Do any additional setup after loading the view.
 
        
    
      
        //ticketLabel.text = n.getBrand()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
