//
//  TotalManipulation.swift
//  day3
//
//  Created by MacStudent on 2018-03-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class TotalManipulation
{
    
    
    init()
    {
        
    }
    
}
