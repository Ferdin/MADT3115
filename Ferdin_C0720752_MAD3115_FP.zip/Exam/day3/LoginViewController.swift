//
//  LoginViewController.swift
//  day3
//
//  Created by MacStudent on 2018-02-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

  
    @IBOutlet weak var userEmailTextField: UITextField!
    
    @IBOutlet weak var userPasswordTextField: UITextField!
    
    @IBOutlet weak var myRememberSwitch: UISwitch!
    var myUserDefault: UserDefaults!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    myUserDefault  = UserDefaults.standard
        if let userEmail = myUserDefault.value(forKey: "userEmail")
        {
            userEmailTextField.text = userEmail as? String
        }
        
        if let userPassword = myUserDefault.value(forKey: "userPassword")
        {
            userPasswordTextField.text = userPassword as? String
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func segue()
    {
        let storyBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let NextVC = storyBoard.instantiateViewController(withIdentifier: "HomeVC") as! HomeMenuViewController
        self.present(NextVC,animated: true,completion: nil)
        
        
    }
    
    @IBAction func loginButtonTapped(_ sender: Any) {
        
        let userEmail = userEmailTextField.text
        let userPassword = userPasswordTextField.text
        
        
      
        // for  checking empty textfields
        if(userEmail!.isEmpty || userPassword!.isEmpty)
        {
            let myAlert = UIAlertController(title: "Message", message: " Enter Valid Email and Password", preferredStyle: UIAlertControllerStyle.actionSheet)
            let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default,handler:nil)
            myAlert.addAction(okAction)
            self.present(myAlert, animated: true, completion: nil)
            
        }
      
       // var isLogin = false
        
        
      /*  for item in RegisterPageViewController.addUsers {
            if userEmail == item.uEmail && userPassword == item.uPassword
            {
                if self.myRememberSwitch.isOn{
                    self.myUserDefault.set(userEmailTextField.text, forKey: "userEmail")
                    self.myUserDefault.set(userPasswordTextField.text, forKey: "userPassword")
                    
                }
                else {
                    self.myUserDefault.removeObject(forKey: "userEmail")
                    self.myUserDefault.removeObject(forKey: "userPassword")
                }
                let alert = UIAlertController(title: title, message: "welcome", preferredStyle: UIAlertControllerStyle.alert)
                let okAction = UIAlertAction(title: "ok", style:UIAlertActionStyle.default, handler: {_ in self.segue()})
                alert.addAction(okAction)
                self.present(alert,animated: true,completion: nil)
                //MOve to Home screen
                isLogin = true
                break;
            }
            
        }
        
        if !isLogin {
            let myAlert = UIAlertController(title: "Message", message: " Login Failed! ", preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default,handler:nil)
            myAlert.addAction(okAction)
            self.present(myAlert, animated: true, completion: nil)
        }*/
        
  // for comparing data with stored data
     
       
       
        else
        {
        var val = 0
        let listOfUser = Register.getAllusers()
        for (key , value) in listOfUser
        {
            if (userEmailTextField.text == value.uEmail && userPasswordTextField.text == value.uPassword)
            {
                val = val + 1
                break
            }
            
        }
        if(val > 0) {
            
    
        
            if self.myRememberSwitch.isOn{
                self.myUserDefault.set(self.userEmailTextField.text, forKey: "userEmail")
                self.myUserDefault.set(self.userPasswordTextField.text, forKey: "userPassword")
               
                }
            else {
                self.myUserDefault.removeObject(forKey: "userEmail")
                self.myUserDefault.removeObject(forKey: "userPassword")
            }
            let alert = UIAlertController(title: title, message: "welcome", preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "ok", style:UIAlertActionStyle.default, handler: {_ in self.segue()})
            alert.addAction(okAction)
            self.present(alert,animated: true,completion: nil)
            
            //MOve to Home screen
            }
       
            else // displaying alert if data doesn't match
       {
        let myAlert = UIAlertController(title: "Message", message: " Login Failed! ", preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default,handler:nil)
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
        
            }
            
        }
 
        
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
}
