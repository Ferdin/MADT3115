//
//  HomeMenuViewController.swift
//  day3
//
//  Created by MacStudent on 2018-02-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class HomeMenuViewController: UIViewController {

  
    
    
    @IBAction func contactButtonTapped(_ sender: UIButton) {
        
        let alert=UIAlertController(title: "Conatct Us", message: "+1 416 258 2261     9.00AM - 8.00PM ", preferredStyle: UIAlertControllerStyle.alert)
        let actionOk=UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
        alert.addAction(actionOk)
        self.present(alert, animated: true, completion: nil)
        
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func myLogoutBtn(_ sender: UIButton) {
        let storyBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let NextVC = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginViewController
        self.present(NextVC,animated: true,completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
