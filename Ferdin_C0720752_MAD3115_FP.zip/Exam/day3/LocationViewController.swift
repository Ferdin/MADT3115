//
//  LocationViewController.swift
//  day3
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class LocationViewController: UIViewController ,CLLocationManagerDelegate{

 
    @IBAction func myMapSegment(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex==0
        {
            self.myMap.mapType=MKMapType.standard
        }
        else
        
        {
            self.myMap.mapType=MKMapType.satellite
        }
    }
    @IBOutlet weak var myMap: MKMapView!
    //let regionRadius: CLLocationAccuracy = 500
    var locationManager:CLLocationManager!
    
    let lambtonCollegelocation=CLLocation(latitude: 43.773257, longitude: -79.335899)
    let cntowerlocation=CLLocation(latitude: 43.642566, longitude: -79.387077)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myMap.mapType=MKMapType.standard
         self.myMap.isZoomEnabled=true
        
      
   //  let initialLocation = CLLocation(latitude: 21.282778, longitude: -157.829444)
        
        centerMapOnLocation(location: lambtonCollegelocation)
         setMarkerOnMap(location: lambtonCollegelocation, title: "Lambton college",subTitle: "265 yorkland road, Toronto")
        
        locationManager = CLLocationManager()
        locationManager.delegate=self
        locationManager.desiredAccuracy=kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
       
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   //centre map on specific locatiobns
    
    let regionRadius: CLLocationDistance = 10000000
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius, regionRadius)
    myMap.setRegion(coordinateRegion, animated: true)
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error : \(error)")
    }
    
    func setMarkerOnMap(location: CLLocation,title:String,subTitle:String)
    {
        // Drop a pin at user's Current Location
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = title
        myAnnotation.subtitle = subTitle
        myMap.addAnnotation(myAnnotation)
    }
    func centermapOnLocation(location:CLLocation)
    {
        let coordinateregion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius, regionRadius)
        myMap.setRegion(coordinateregion, animated: true)
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("new location found")
        let loc=locations[0]
        self.centermapOnLocation(location: loc)
        
        self.setMarkerOnMap(location: loc,title: "Current", subTitle: "My current location")
    }
    
        
    }
  
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
 }*/
