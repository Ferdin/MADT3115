//
//  AddTicket.swift
//  day3
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class AddTicket
{
    
    var Number:String!
    var Brand:String!
    var Color:String!
    var Lane:String!
    var Spot:String!
    var Payment:String!
    var Rate:String!
    
    static var CarDetail=[String:AddTicket]()
    
    init()
    {
    }
    
    init(Number:String,Brand:String,Color:String,Lane:String,Spot:String,Payment:String,Rate:String) {
         
        
        self.Number = Number
        self.Brand = Brand
        self.Color = Color
        self.Lane = Lane
        self.Spot = Spot
        self.Payment = Payment
        self.Rate = Rate
        
    }

   
    
    
    

static func addticket (ticket:AddTicket)->Bool
{
    /*
    if (self.CarDetail[ticket.Number] == nil && self.CarDetail[ticket.Brand] == nil && self.CarDetail[ticket.Color] == nil && self.CarDetail[ticket.Lane] == nil && self.CarDetail[ticket.Spot] == nil && self.CarDetail[ticket.Payment] == nil && self.CarDetail[ticket.Rate] == nil ){
        
        self.CarDetail[ticket.Number] = ticket
        self.CarDetail[ticket.Brand] = ticket
        self.CarDetail[ticket.Color] = ticket
        self.CarDetail[ticket.Lane] = ticket
        self.CarDetail[ticket.Spot] = ticket
        self.CarDetail[ticket.Payment] = ticket
        self.CarDetail[ticket.Rate] = ticket
        
        return true
    }
    
    return false
    */
   
    if self.CarDetail[ticket.Brand] == nil
    {
        self.CarDetail[ticket.Brand] = ticket
        return true
    }
    return false
}
static func  getAlltickets()->[String:AddTicket]
{
    return CarDetail
}
}

