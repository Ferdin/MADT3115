//
//  ProfileUpdateViewController.swift
//  day3
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ProfileUpdateViewController: UIViewController {

    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let usrList = Register.getAllusers()
        var s = String()
        var n = String()
        var d = String()
        
        for (key, value) in usrList{
            s = value.uName
            n = value.uEmail
            d = value.uPassword
        }
        print(s)
        
        nameTxt.text = s
        emailTxt.text = n
        Password.text = d
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func updateBtn(_ sender: Any) {
        
        
        let userName = nameTxt.text
        let userEmail = emailTxt.text
        let userPassword = Password.text
      
        let r1 = Register()
        
        r1.uName = userName
        r1.uEmail = userEmail
        r1.uPassword = userPassword
        
        
        
        
        
        // RegisterPageViewController.addUsers.append(Register(uname: userName!, uemail: userEmail!, upass: userPassword!))
        
        // check for empty fields
        if ((userName?.isEmpty)! || (userEmail!.isEmpty) || (userPassword!.isEmpty) )
        {
            // Display alert message
            displayMyAlertMessage(userMessage: "All Fields are Required");
            //return;
        }
       
            
            // store data
            //  UserDefaults.standard.set(userName, forKey: "userName")
            //  UserDefaults.standard.set(userEmail,forKey: "userEmail")
            //  UserDefaults.standard.set(userPassword,forKey: "userPassword")
            // UserDefaults.standard.synchronize()
            
            // Display alert message with confirmation
        else
        {
            let flag =  Register.addUsers(user: r1)
            if flag == true
            {
                print("data saved")
                
            }
            else{
                print("no data")
            }
            let myAlert = UIAlertController(title: "Alert", message: "Updation is successful.Thank you", preferredStyle: UIAlertControllerStyle.alert)
            
            let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {_ in
                self.segue()}
            myAlert.addAction(okAction)
            self.present(myAlert, animated: true, completion: nil)
            
            
        }
    }
    func displayMyAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    func segue()
    {
        let storyBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let NextVC = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginViewController
        self.present(NextVC,animated: true,completion: nil)
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
