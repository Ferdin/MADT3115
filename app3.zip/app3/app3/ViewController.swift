//
//  ViewController.swift
//  app3
//
//  Created by MacStudent on 2018-02-22.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myText: UITextField!
    @IBOutlet weak var mySwitch: UISwitch!
    
   
    @IBAction func mySlider(_ sender: UISlider) {
        myText.text = String(sender.value)
        
    }
    @IBOutlet weak var myImage: UIImageView!
    @IBAction func mySwitch(_ sender: UISwitch) {
        if sender.isOn
        {
            myText.text = "Text is on"
            myImage.image = UIImage(named: "lion.png")
        }
        else
        {
            myText.text = "Text is off"
             myImage.image = UIImage(named: "gorilla.png")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

